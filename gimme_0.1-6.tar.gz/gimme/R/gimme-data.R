#' Example heterogeneous data, 1
#'
#' This data contains simulated time-series data for a single individual with 50 time points and 3 variables, or regions of interest.
#'
#' @docType data
#' @keywords datasets
#' @name ts1
#' @usage ts1
#' @format A data frame with 50 observations on 3 variables.
NULL

#' Example heterogeneous data, 2
#'
#' This data contains simulated time-series data for a single individual with 50 time points and 3 variables, or regions of interest.
#'
#' @docType data
#' @keywords datasets
#' @name ts2
#' @usage ts2
#' @format A data frame with 50 observations on 3 variables.
NULL

#' Example heterogeneous data, 3
#'
#' This data contains simulated time-series data for a single individual with 50 time points and 3 variables, or regions of interest.
#'
#' @docType data
#' @keywords datasets
#' @name ts3
#' @usage ts3
#' @format A data frame with 50 observations on 3 variables.
NULL

#' Example heterogeneous data, 4
#'
#' This data contains simulated time-series data for a single individual with 50 time points and 3 variables, or regions of interest.
#'
#' @docType data
#' @keywords datasets
#' @name ts4
#' @usage ts4
#' @format A data frame with 50 observations on 3 variables.
NULL

#' Example heterogeneous data, 5
#'
#' This data contains simulated time-series data for a single individual with 50 time points and 3 variables, or regions of interest.
#'
#' @docType data
#' @keywords datasets
#' @name ts5
#' @usage ts5
#' @format A data frame with 50 observations on 3 variables.
NULL

